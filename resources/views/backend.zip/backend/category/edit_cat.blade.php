@extends('backend.admin_master')
  
@section('title')
update Printer cat 
@endsection
  
@section('content')
<h2 class="text-center text-info">Edit Category  </h2>
<form  action="{{route('update.printercat',[$editdata->id])}}" method="post">
    @csrf
  <div class="form-group">
    <label for="name">Printer category</label>
    <input type="text" class="form-control" id="name" aria-describedby="nameHelp" name="name" placeholder="enter printer category" 
    value="{{$editdata->name}}">

  </div>
  <div class="form-group form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <button type="submit" class="btn btn-primary">update</button>
</form>
@endsection