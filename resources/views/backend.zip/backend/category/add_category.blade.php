@extends('backend.admin_master')
  
@section('title')
Printer cat view
@endsection
  
@section('content')

<form  action="{{route('printer.cat_store')}}" method="post">
    @csrf
  <div class="form-group">
    <label for="name">Printer category</label>
    <input type="text" class="form-control" id="name" aria-describedby="nameHelp" name="name" placeholder="enter printer category">

  </div>
  <div class="form-group form-check">
    <input type="checkbox" class="form-check-input" id="exampleCheck1">
    <label class="form-check-label" for="exampleCheck1">Check me out</label>
  </div>
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
@endsection