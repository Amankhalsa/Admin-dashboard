@extends('backend.admin_master')
  
@section('title')
Client mails
@endsection
  
@section('content')

                    <div class="container-fluid">
@if(session('sucess'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
<strong>{{session('sucess')}}</strong> 
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
@endif  

@if(session('danger'))
<div class="alert alert-danger alert-dismissible fade show" role="alert">
<strong>{{session('danger')}}</strong> 
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
@endif  
                <h3 class="text-dark mb-4">Hi.. {{Auth::user()->name}}</h3>
                <div class="card shadow">
                    <div class="card-header py-3">
                        <p class="text-primary m-0 font-weight-bold"><a href="#">Total: {{count($mail_data)}} </a></p>
                  
                    </div>
                    <div class="card-body">

                        <div class="table-responsive table mt-2" id="dataTable" role="grid" aria-describedby="dataTable_info">
                            <table id="example" class="table table-striped table-bordered" style="width:100%">
                                <thead>
                                    <tr>
                                      
                                        <th>No</th>
                                        <th>Images</th>
                                        <th>Email</th>                           <th>phone</th>                         <th>Message</th>
                                        <th>Edit</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>

                                @foreach($mail_data as $key => $value)
                                    <tr>
<td>{{ $key+1}}</td>

<td><img class="rounded-circle mr-2" width="30" height="30" src="{{asset('backend/assets/img/user.jpg')}}"> {{$value->name}}</td>
<td>{{ $value->email}}</td>
<td>{{ $value->phone}}</td>
<td>{{ $value->message}}</td>
<td><a href="">
<button class="btn btn-success" style="margin-left: 5px;" type="submit">
<i class="fa fa-check" style="font-size: 15px;"></i>
</button></a></td>

<td><a href="" onclick="return alert('do you want to delelte');">
<button class="btn btn-danger" style="margin-left: 5px;" type="submit" >
<i class="fa fa-trash" style="font-size: 15px;"></i>
</button></a></td>
                                    </tr>
                                    @endforeach 
         
                                   
                                </tbody>
             
                            </table>
                        </div>
                      
                    </div>
                </div>
            </div>

@endsection