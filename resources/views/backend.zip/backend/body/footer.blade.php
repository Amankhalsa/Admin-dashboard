<footer class="bg-white sticky-footer">
        <div class="container my-auto">
            <div class="text-center my-auto copyright"><span>Copyright © Brand {{date('Y')}}</span></div>
        </div>
    </footer>