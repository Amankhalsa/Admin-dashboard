@extends('backend.admin_master')
  
@section('title')
Add Data 
@endsection
  
@section('content')
<div class="container-fluid ">

<div class="container">
  
<div class="py-1">

<form action="{{route('store.imagepost')}}" method="post" class=" py-5 my-5" enctype="multipart/form-data">
@csrf



       <div class="form-group">
        <label for="link">link :<span class="text-danger">*</span></label>
        <input type="url" class="form-control" id="link" aria-describedby="textHelp" name="link" placeholder="Blog link">
           @error('link') 
           <span class="text-danger">{{ $message }} </span>
           @enderror 
      
       </div>

       <div class="form-group">
        <label for="title">Title :<span class="text-danger">*</span></label>
        <input type="text" class="form-control" id="title" aria-describedby="textHelp" name="title" placeholder="blog title">
           @error('title') 
           <span class="text-danger">{{ $message }} </span>
           @enderror 
   
       </div>
<!-- text  -->

<!-- image  -->
		<div class="form-group">
        
			<div class="controls">

			<img src="{{asset('backend/assets/img/user.jpg')}}" width="100" height="100" id="output">
			</div>
	</div>
       
<!-- image  -->
<div class="form-group">
			<h5>Profile Image :<span class="text-danger">*</span></h5>
			<div class="controls">
			<input type="file" name="image" class="form-control" accept="image/*" onchange="document.getElementById('output').src = window.URL.createObjectURL(this.files[0])">
			</div>
         @error('image') 
           <span class="text-danger">{{ $message }} </span>
           @enderror 
           <small id="textHelp" class="form-text text-muted">We'll never share your Detail with anyone else.</small>
	</div>

       <button type="submit" class="btn btn-primary">Publish</button>
   </form>
</div>
</div>

</div>


@endsection