@extends('backend.admin_master')
  
@section('title')
Add HP printer 
@endsection
  
@section('content')
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  
@section('content')
<div class="container-fluid ">

<div class="container">
  <h2 class="text-center text-info">Add Hp Printer</h2>
<div class="py-1">

<form action="{{route('store.hp_printer')}}" method="post" class="" enctype="multipart/form-data">
@csrf
<div class="add_item">  

<!-- ==================== -->
<div class="form-group ">
        <label for="Category">Printer Category :</label>
        <select name="cat_id" id="select" required="" class="form-control">
				<option value="" selected="" disabled="">Select printer Category</option>
				@foreach($get_data as $value)
				<option value="{{$value->id}}">{{$value->name}}</option>
				@endforeach
				</select>
       </div>
<!-- ======================== -->
       <div class="form-group">
        <label for="link">link :<span class="text-danger">*</span></label>
        <input type="url" class="form-control" id="link" aria-describedby="textHelp" name="link" placeholder=" link" value="http://s2vmart.com/shop/hp"> 
           @error('link') 
           <span class="text-danger">{{ $message }} </span>
           @enderror       
       </div>
<!-- ======================== -->
       <div class="form-group">
        <label for="title">Title :<span class="text-danger">*</span></label>
        <input type="text" class="form-control" id="title" aria-describedby="textHelp" name="title" placeholder=" title">
           @error('title') 
           <span class="text-danger">{{ $message }} </span>
           @enderror 
       </div>
<!-- ======================== -->
<!-- text  -->
       <!------------------------->
       <div class="row">
           <div class="col-md-6"> 
                  <!------------------------->
           <div class="form-group ">
        <label for="price">Price :<span class="text-danger"></span></label>
        <input type="number" class="form-control" id="price" aria-describedby="textHelp" name="price" placeholder="price ">
        
           @error('price') 
           <span class="text-danger">{{ $message }} </span>
           @enderror 
       </div>
       <!------------------------->
           </div>
           <div class="col-md-6">
                      
              <!------------------------->
<div class="form-group ">
        <label for="offerprice">Offer price :<span class="text-danger"></span></label>
        <input type="number" class="form-control" id="offerprice" aria-describedby="textHelp" name="offerprice" placeholder="offer price">
        
           @error('offerprice') 
           <span class="text-danger">{{ $message }} </span>
           @enderror 
       </div>
       <!------------------------->
               </div>
       </div>

       <div class="row">
           <div class="col-md-6"> 
        <!------------------------->
        <div class="form-group ">
        <label for="chatlink">Chat link :<span class="text-danger"></span></label>
        <input type="text" class="form-control" id="chatlink" aria-describedby="textHelp" name="chatlink" placeholder="Http://www.example.com" value="javascript:void(Tawk_API.toggle())">
        
           @error('chatlink') 
           <span class="text-danger">{{ $message }} </span>
           @enderror 
       </div>
       <!------------------------->
       </div>
       <div class="col-md-6">
<div class="form-group ">
        <label for="alt">Alt Tag :<span class="text-danger"></span></label>
        <input type="text" class="form-control" id="alt" aria-describedby="textHelp" name="alt" placeholder="Alt text for image">
        
           @error('alt') 
           <span class="text-danger">{{ $message }} </span>
           @enderror 
       </div>
       <!------------------------->
       </div>
       </div
<!-- image  -->
		<div class="form-group">
        
			<div class="controls">

			<img src="{{asset('backend/assets/img/user.jpg')}}" width="100" height="100" id="output">
			</div>
	</div>
       
<!-- image  -->
<div class="form-group">
			<h5>Profile Image :<span class="text-danger">*</span></h5>
			<div class="controls">
			<input type="file" name="image" class="form-control" accept="image/*" onchange="document.getElementById('output').src = window.URL.createObjectURL(this.files[0])">
			</div>
         @error('image') 
           <span class="text-danger">{{ $message }} </span>
           @enderror 
	</div>


              <!-- list row start  -->

<!-- list row end  -->
       </div>
       <button type="submit" class="btn btn-primary">Publish</button>
   </form>

</div>
</div>

</div>
<!-- ==================== END top part  -->



@endsection