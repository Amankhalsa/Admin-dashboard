@extends('backend.admin_master')
  
@section('title')
Hp printer view
@endsection
  
@section('content')

                    <div class="container-fluid">
            
@if(session('sucess'))
<div class="alert alert-success alert-dismissible fade show" role="alert">
<strong>{{session('sucess')}}</strong> 
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
@endif  

@if(session('danger'))
<div class="alert alert-danger alert-dismissible fade show" role="alert">
<strong>{{session('danger')}}</strong> 
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">&times;</span>
</button>
</div>
@endif  
        <h2 class='text-center text-info'>Hp printer</h2>
                <h3 class="text-dark mb-4">Hi.. {{Auth::user()->name}}</h3>
                <div class="card shadow">
                    <div class="card-header py-3">
                        <p class="text-primary m-0 font-weight-bold "><a href="{{route('add.hp_printer')}}" class="btn btn-info"> Add printer </a></p>
                    </div>
                    <div class="card-body">

                        <div class="table-responsive table mt-2" id="dataTable" role="grid" aria-describedby="dataTable_info">
                            <table id="example" class="table table-striped table-bordered" style="width:100%">
                                <thead>
                                    <tr>
                                      
                                        <th>No</th>
                                        <th>Images</th>
                                         <th>Title</th>
                                        <th>Category name</th>
                                        <th>price/offer</th>
                                     
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>

   @foreach($get_data as $key => $value)                       
<tr>
<td class="text-center">{{ $key+1}}</td>

<td class="text-center"><img class="rounded-circle mr-2 zoom" width="60" height="55" src="{{asset('backend/assets/img/hpprinters/'.$value->image)}}"></td>
<td>{{$value->title}}</td>
<td class="text-center">{{$value['getcat_name']['name']}}</td>
<td class="text-center"><strike>${{$value->price}}</strike>
<p>${{$value->offerprice}}<p>
</td>

<td class="text-center">
<a href="{{route('edit.hp_printer',$value->id)}}">
<button class="btn btn-success" style="margin-left: 5px;" type="submit">
<i class="fa fa-check" style="font-size: 15px;"></i>
</button></a>

<a href="#" id="delete">
<button class="btn btn-danger" style="margin-left: 5px;" type="submit" >
<i class="fa fa-trash" style="font-size: 15px;"></i>
</button></a>
                                        </td>
                               
                                    </tr>
                  
         
    @endforeach                            
                                </tbody>
           
                            </table>
                        </div>
                      
                    </div>
                </div>
            </div>

@endsection