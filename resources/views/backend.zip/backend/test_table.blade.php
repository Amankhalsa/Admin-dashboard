@extends('backend.admin_master')
  
@section('title')
Pagination
@endsection

@section('content')
      <h2 class="text-center">Pagignation sample </h2>
<div class="container pt-5">


<section class="wrapper">
    <div class="container-fostrap">
        <div>

            <h2 class="heading alert alert-success">
      HP Printers 
            </h2>
        </div>
        <div class="content">

            <div class="container">

                <div class="row">
                      @foreach($get_data as $key => $value)
                    <div class="col-xs-12 col-sm-4">
                        <div class="card">
                            <a class="img-card" href="http://www.fostrap.com/2016/03/bootstrap-3-carousel-fade-effect.html">
                            <img src="{{asset('backend/assets/img/hpprinters/'.$value->image)}}" />
                          </a>
                            <div class="card-content">
                                <h5 class="card-title blog_heading ">
                                    <a href="http://www.fostrap.com/2016/03/bootstrap-3-carousel-fade-effect.html"> {{$value->title}}
                                  </a>
                                </h5>
                                <p class="">
                                   <span>
                                <a href="http://www.fostrap.com/2016/03/bootstrap-3-carousel-fade-effect.html" class="btn btn-info  text-left">
                                  <strike>  ${{$value->price}} </strike>
                                </a>
                                      <a href="http://www.fostrap.com/2016/03/bootstrap-3-carousel-fade-effect.html" class="btn btn-info text-right">
                                   ${{$value->offerprice}}
                                </a>
                                </span>                            </p>
                            </div>
                            <div class="card-read-more">
                                <div class="rating text-left"><img src="{{asset('frontend/assets/img/stars/star.svg')}}"><img src="{{asset('frontend/assets/img/stars/star.svg')}}"><img src="{{asset('frontend/assets/img/stars/star.svg')}}"><img src="{{asset('frontend/assets/img/stars/star-half-empty.svg')}}"><img src="{{asset('frontend/assets/img/stars/star-empty.svg')}}"></div>
                                      <a href="http://www.fostrap.com/2016/03/bootstrap-3-carousel-fade-effect.html" class="btn btn-success btn-block">
                                 <i class="fa fa-cart-arrow-down" aria-hidden="true"></i> Add to Cart
                                </a>
                            </div>
                        </div>
                    </div>
           @endforeach
                    <!-- ens -->
                                                              </div>
                      Showing {{ $get_data->firstItem() }}–{{ $get_data->lastItem() }} of {{ $get_data->total() }} results

  <div class="float-right">

{{$get_data->links()}}
</div>  

            </div>
        </div>
    </div>
</section>

@endsection